package com.authsystem.commands;

import com.authsystem.AuthSystem;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class LoginCommand implements CommandExecutor {

    private final AuthSystem plugin;

    public LoginCommand(AuthSystem plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Este comando so pode ser usado dentro do jogo.");
            return true;
        }

        if (plugin.getSessionManager().isPremium(player)) {
            player.sendMessage(ChatColor.YELLOW + "Sua conta original ja foi verificada automaticamente. Nao e preciso usar /login.");
            return true;
        }

        if (plugin.getSessionManager().isAuthenticated(player)) {
            player.sendMessage(ChatColor.YELLOW + "Voce ja esta logado.");
            return true;
        }

        if (!plugin.getPlayerDataManager().isRegistered(player.getName())) {
            player.sendMessage(ChatColor.RED + "Voce ainda nao tem conta. Use /registro <senha> <confirmar-senha>.");
            return true;
        }

        if (args.length != 1) {
            player.sendMessage(ChatColor.RED + "Uso correto: /login <senha>");
            return true;
        }

        String senha = args[0];

        if (plugin.getPlayerDataManager().checkPassword(player.getName(), senha)) {
            plugin.getSessionManager().setAuthenticated(player, true);
            plugin.getSessionManager().cancelTimeout(player);
            player.sendMessage(ChatColor.GREEN + "Login efetuado com sucesso! Bem-vindo(a) de volta.");
        } else {
            int tentativas = plugin.getSessionManager().addLoginAttempt(player);
            int max = plugin.getConfig().getInt("max-tentativas-login", 4);
            player.sendMessage(ChatColor.RED + "Senha incorreta! (" + tentativas + "/" + max + ")");
            if (tentativas >= max) {
                player.kickPlayer(ChatColor.RED + "Muitas tentativas de login incorretas.");
            }
        }

        return true;
    }
}
