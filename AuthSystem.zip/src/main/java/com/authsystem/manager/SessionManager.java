package com.authsystem.manager;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Guarda em memoria (nao precisa persistir em disco) quem esta logado,
 * quem foi identificado como conta original, localizacao de "congelamento"
 * e tarefas de timeout, enquanto o jogador esta online.
 */
public class SessionManager {

    private final Set<UUID> authenticated = new HashSet<>();
    private final Set<UUID> premium = new HashSet<>();
    private final Map<UUID, Location> frozenLocation = new HashMap<>();
    private final Map<UUID, Integer> loginAttempts = new HashMap<>();
    private final Map<UUID, BukkitTask> timeoutTasks = new HashMap<>();

    public boolean isAuthenticated(Player player) {
        return authenticated.contains(player.getUniqueId());
    }

    public void setAuthenticated(Player player, boolean value) {
        if (value) {
            authenticated.add(player.getUniqueId());
        } else {
            authenticated.remove(player.getUniqueId());
        }
    }

    public boolean isPremium(Player player) {
        return premium.contains(player.getUniqueId());
    }

    public void markPremium(UUID uuid) {
        premium.add(uuid);
    }

    public void setFrozenLocation(Player player, Location loc) {
        frozenLocation.put(player.getUniqueId(), loc);
    }

    public Location getFrozenLocation(Player player) {
        return frozenLocation.get(player.getUniqueId());
    }

    public int addLoginAttempt(Player player) {
        return loginAttempts.merge(player.getUniqueId(), 1, Integer::sum);
    }

    public void setTimeoutTask(Player player, BukkitTask task) {
        cancelTimeout(player);
        timeoutTasks.put(player.getUniqueId(), task);
    }

    public void cancelTimeout(Player player) {
        BukkitTask task = timeoutTasks.remove(player.getUniqueId());
        if (task != null) {
            task.cancel();
        }
    }

    public void clear(Player player) {
        UUID uuid = player.getUniqueId();
        authenticated.remove(uuid);
        premium.remove(uuid);
        frozenLocation.remove(uuid);
        loginAttempts.remove(uuid);
        cancelTimeout(player);
    }
}
